package com.example.onlinesportshopee.exception;

public class PaymentNotFoundException extends Exception{
	
	public PaymentNotFoundException(String message) {
		super(message);
	}

}
