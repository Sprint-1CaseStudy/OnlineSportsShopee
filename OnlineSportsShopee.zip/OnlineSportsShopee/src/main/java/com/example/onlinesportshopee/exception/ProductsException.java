package com.example.onlinesportshopee.exception;

public class ProductsException extends Exception {
	
	private static final long serialVersionUID = 1L;

	public ProductsException(String message)
	{
		super(message);
	}

}
