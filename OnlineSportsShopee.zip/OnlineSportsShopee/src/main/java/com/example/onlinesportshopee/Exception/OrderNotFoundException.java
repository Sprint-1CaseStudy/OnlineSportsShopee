package com.example.onlinesportshopee.Exception;

public class OrderNotFoundException extends Exception {

	public OrderNotFoundException(String message) {
		super(message);
	}
	
}
