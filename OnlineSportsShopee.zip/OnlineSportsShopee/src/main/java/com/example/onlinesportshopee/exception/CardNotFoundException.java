package com.example.onlinesportshopee.exception;

public class CardNotFoundException extends Exception {
	private static final long serialVersionUID = 1L;
	
	public CardNotFoundException(String message) {
		super(message);
	}
	
}
