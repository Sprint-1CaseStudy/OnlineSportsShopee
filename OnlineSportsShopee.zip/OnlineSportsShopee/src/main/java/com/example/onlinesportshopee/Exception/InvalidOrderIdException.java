package com.example.onlinesportshopee.Exception;

public class InvalidOrderIdException extends Exception{

	public InvalidOrderIdException(String message) {
		super(message);
	}
}
