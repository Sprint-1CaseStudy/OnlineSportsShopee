package com.example.onlinesportshopee.Exception;

public class ProductsException extends Exception {
	
	private static final long serialVersionUID = 1L;

	public ProductsException(String message)
	{
		super(message);
	}

}
