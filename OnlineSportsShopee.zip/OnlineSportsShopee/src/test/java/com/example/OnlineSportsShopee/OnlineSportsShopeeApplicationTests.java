package com.example.OnlineSportsShopee;

import org.junit.jupiter.api.Test;

import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OnlineSportsShopeeApplicationTests {

	@Test
	void contextLoads() {
	}

}
